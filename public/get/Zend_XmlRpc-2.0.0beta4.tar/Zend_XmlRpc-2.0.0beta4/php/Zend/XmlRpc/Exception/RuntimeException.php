<?php

namespace Zend\XmlRpc\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{}
