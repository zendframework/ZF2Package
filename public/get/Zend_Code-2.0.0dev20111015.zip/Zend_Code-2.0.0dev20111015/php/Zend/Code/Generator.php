<?php

namespace Zend\Code;

interface Generator
{
    public function generate();
}
