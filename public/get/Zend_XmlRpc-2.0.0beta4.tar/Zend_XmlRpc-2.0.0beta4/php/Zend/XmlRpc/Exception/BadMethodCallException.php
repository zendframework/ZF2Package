<?php

namespace Zend\XmlRpc\Exception;

class BadMethodCallException
    extends \BadMethodCallException
    implements ExceptionInterface
{}
