<!DOCTYPE TS>
<TS>
<context />
    <name>Test</name>
    <message>
        <source>Message 1</source>
        <translation>Nachricht 1</translation>
    </message>
    <message>
        <source>Message 8</source>
        <translation>Nachricht 8</translation>
    </message>
</context>
</TS>
