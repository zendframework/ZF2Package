<?php

namespace Zend\Filter\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{
}
