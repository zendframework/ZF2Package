<?php
/**
 * @namespace
 */
namespace Zend\Text\Table\Exception;

class OverflowException
    extends \OverflowException
    implements \Zend\Text\Exception
{
}
