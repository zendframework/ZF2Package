<?php

namespace Zend\Validator\Exception;

class ExtensionNotLoadedException
    extends RuntimeException
{}