<?php

namespace Zend\InfoCard\XML\Security\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\InfoCard\XML\Security\Exception
{}