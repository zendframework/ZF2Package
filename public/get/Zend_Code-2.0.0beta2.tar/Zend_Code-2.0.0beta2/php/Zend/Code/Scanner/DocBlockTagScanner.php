<?php

namespace Zend\Code\Scanner;

class DocCommentTagScanner
{
    // @todo
}
