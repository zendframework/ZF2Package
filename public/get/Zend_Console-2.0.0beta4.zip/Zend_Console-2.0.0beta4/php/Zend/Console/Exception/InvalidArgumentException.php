<?php

namespace Zend\Console\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements ExceptionInterface
{
    
} 
