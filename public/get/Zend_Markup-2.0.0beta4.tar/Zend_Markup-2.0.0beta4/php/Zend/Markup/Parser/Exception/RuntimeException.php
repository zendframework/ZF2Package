<?php

namespace Zend\Markup\Parser\Exception;

use Zend\Markup\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}