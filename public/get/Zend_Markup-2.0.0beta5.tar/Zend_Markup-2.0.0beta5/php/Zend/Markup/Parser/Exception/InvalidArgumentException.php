<?php

namespace Zend\Markup\Parser\Exception;

use Zend\Markup\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{}