<?php
/**
 * @namespace
 */
namespace Zend\Text\Table\Exception;

class OutOfBoundsException 
    extends \OutOfBoundsException
    implements \Zend\Text\Exception
{
}
