<?php

namespace Zend\OpenId\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements ExceptionInterface
{}