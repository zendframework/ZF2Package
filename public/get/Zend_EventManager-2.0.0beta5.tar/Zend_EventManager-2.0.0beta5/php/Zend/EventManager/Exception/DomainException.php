<?php

namespace Zend\EventManager\Exception;

class DomainException extends \DomainException implements ExceptionInterface
{
}
