<?php

namespace Zend\Stdlib\Exception;

use Zend\Stdlib\Exception;

class InvalidArgumentException 
    extends \InvalidArgumentException 
    implements Exception
{
}
