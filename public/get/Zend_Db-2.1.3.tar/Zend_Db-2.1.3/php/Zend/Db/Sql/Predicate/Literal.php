<?php

namespace Zend\Db\Sql\Predicate;

use Zend\Db\Sql\Literal as BaseLiteral;

class Literal extends BaseLiteral implements PredicateInterface
{

}
