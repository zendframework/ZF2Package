<?php
namespace ZFToolTest\Diagnostics\TestAssets;

use ZFTool\Diagnostics\Reporter\AbstractReporter;

class DummyReporter extends AbstractReporter
{

}
