<?php

namespace Zend\Feed\Writer\Exception;

use Zend\Feed\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}