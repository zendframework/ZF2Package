### ZendQueue component

Master: [![Build Status](https://secure.travis-ci.org/zendframework/ZendQueue.png?branch=master)](http://travis-ci.org/zendframework/ZendQueue)

You can install using:

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```

At that point, follow the instructions in the documentation folder for actual
usage of the component. (Documentation is forthcoming.)
