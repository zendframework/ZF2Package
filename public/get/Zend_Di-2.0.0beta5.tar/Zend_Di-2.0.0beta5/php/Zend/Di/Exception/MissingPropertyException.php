<?php
namespace Zend\Di\Exception;

use DomainException;

class MissingPropertyException extends DomainException implements ExceptionInterface
{
}
