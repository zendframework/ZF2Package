<?php

namespace Zend\Module\Exception;

use Zend\Module\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements Exception
{}
