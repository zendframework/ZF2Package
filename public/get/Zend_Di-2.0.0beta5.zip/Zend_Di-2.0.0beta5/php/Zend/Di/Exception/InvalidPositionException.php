<?php
namespace Zend\Di\Exception;

class InvalidPositionException extends InvalidArgumentException
{
}
