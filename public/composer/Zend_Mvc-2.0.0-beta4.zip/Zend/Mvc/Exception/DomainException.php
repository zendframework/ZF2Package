<?php

namespace Zend\Mvc\Exception;

class DomainException
    extends \DomainException
    implements ExceptionInterface
{}