<?php

namespace Zend\Validator\Exception;

class BadMethodCallException 
    extends \BadMethodCallException
    implements ExceptionInterface
{}