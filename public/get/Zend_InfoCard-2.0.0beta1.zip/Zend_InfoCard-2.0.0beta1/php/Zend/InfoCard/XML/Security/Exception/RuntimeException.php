<?php

namespace Zend\InfoCard\XML\Security\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\InfoCard\XML\Security\Exception
{}