ZendService\Google\Gcm component
================================

Provides support for Google push notifications.

Install dependencies using:

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```
