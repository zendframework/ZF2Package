<?php

namespace Zend\Stdlib;

class Request extends Message implements RequestInterface
{
    // generic request implementation
}
