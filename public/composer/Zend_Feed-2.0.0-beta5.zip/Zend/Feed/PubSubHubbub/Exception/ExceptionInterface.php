<?php

namespace Zend\Feed\PubSubHubbub\Exception;

use Zend\Feed\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{}