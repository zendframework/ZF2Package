ZF Configuration
================

Manage the configuration of a ZF2 project.


Installation
------------

You can install using:

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```
