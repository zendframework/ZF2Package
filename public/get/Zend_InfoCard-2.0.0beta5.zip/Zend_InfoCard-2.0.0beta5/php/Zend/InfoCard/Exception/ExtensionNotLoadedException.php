<?php

namespace Zend\InfoCard\Exception;

class ExtensionNotLoadedException
    extends RuntimeException
{}
