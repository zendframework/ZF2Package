<?php

namespace Zend\Module\Listener\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Module\Listener\Exception
{}
