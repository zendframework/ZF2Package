<?php

namespace Zend\InfoCard\XML\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\InfoCard\XML\Exception
{}