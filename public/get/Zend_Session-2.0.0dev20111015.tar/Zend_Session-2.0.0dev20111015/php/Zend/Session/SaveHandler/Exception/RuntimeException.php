<?php

namespace Zend\Session\SaveHandler\Exception;

class RuntimeException
    extends \Zend\Session\Exception\RuntimeException
    implements \Zend\Session\SaveHandler\Exception
{}
