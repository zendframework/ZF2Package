<?php

namespace Zend\Stdlib;

interface ResponseInterface extends MessageInterface
{

}
