<?php

namespace Zend\Dojo\View\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Dojo\View\Exception
{}