This is a composer based component package from Zend Framework.
The Zend Framework source for this package is located here:

    https://github.com/zendframework/zf2/

You can install using:

    curl -s https://getcomposer.org/installer | php
    php composer.phar install

At that point, follow the instructions in the documentation folder for actual
usage of the component. (Documentation is forthcoming.)