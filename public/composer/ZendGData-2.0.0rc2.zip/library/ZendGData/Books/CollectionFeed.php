<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/zf2 for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 * @package   Zend_GData
 */

namespace ZendGData\Books;

use ZendGData\Books;

/**
 * Describes a Book Search collection feed
 *
 * @category   Zend
 * @package    Zend_Gdata
 * @subpackage Books
 */
class CollectionFeed extends \ZendGData\Feed
{

    /**
     * Constructor for Zend_Gdata_Books_CollectionFeed which
     * Describes a Book Search collection feed
     *
     * @param DOMElement $element (optional) DOMElement from which this
     *          object should be constructed.
     */
    public function __construct($element = null)
    {
        $this->registerAllNamespaces(Books::$namespaces);
        parent::__construct($element);
    }

    /**
     * The classname for individual feed elements.
     *
     * @var string
     */
    protected $_entryClassName = 'ZendGData\Books\CollectionEntry';

}

