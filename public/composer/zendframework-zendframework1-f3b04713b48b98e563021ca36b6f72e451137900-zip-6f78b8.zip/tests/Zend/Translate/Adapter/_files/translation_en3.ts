<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE TS>
<TS>
<context>
    <name>Test</name>
    <message>
        <source>Message 1</source>
        <translation>Message 1 (en)</translation>
    </message>
    <message>
        <source>Message 2</source>
        <translation>Message 2 (en)</translation>
    </message>
    <message>
        <source>Message 3</source>
        <translation>Message 3 (en)</translation>
    </message>
    <message>
        <source>Message 4</source>
        <translation>Message 4 (en)</translation>
    </message>
    <message>
        <source>K�chen M�bel</source>
        <translation>Cooking furniture (en)</translation>
    </message>
    <message>
        <source>Cooking furniture</source>
        <translation>K�chen M�bel (en)</translation>
    </message>
</context>
</TS>
