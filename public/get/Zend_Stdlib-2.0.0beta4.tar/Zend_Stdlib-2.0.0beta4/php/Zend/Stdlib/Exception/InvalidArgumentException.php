<?php

namespace Zend\Stdlib\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements ExceptionInterface
{
}
