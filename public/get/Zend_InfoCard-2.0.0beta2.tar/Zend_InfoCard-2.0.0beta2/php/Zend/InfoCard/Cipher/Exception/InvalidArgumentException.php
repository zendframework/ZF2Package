<?php

namespace Zend\InfoCard\Cipher\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\InfoCard\Cipher\Exception
{}