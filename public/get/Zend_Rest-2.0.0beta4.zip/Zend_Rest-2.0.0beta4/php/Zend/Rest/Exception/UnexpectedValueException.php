<?php

namespace Zend\Rest\Exception;

class UnexpectedValueException
    extends \UnexpectedValueException
    implements ExceptionInterface
{}