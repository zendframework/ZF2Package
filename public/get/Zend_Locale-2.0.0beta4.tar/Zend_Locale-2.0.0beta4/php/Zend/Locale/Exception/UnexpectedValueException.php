<?php
namespace Zend\Locale\Exception;

class UnexpectedValueException
    extends \UnexpectedValueException
    implements ExceptionInterface
{}
