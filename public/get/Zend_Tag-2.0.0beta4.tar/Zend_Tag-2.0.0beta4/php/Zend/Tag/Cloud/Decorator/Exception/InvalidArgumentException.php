<?php

namespace Zend\Tag\Cloud\Decorator\Exception;

use Zend\Tag\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{}