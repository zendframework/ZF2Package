<?php

namespace Zend\Validator\Exception;

class InvalidMagicMimeFileException extends InvalidArgumentException
{}