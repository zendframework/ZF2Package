<?php

namespace Zend\Navigation\Exception;

use Zend\Navigation\Exception;

class OutOfBoundsException extends \InvalidArgumentException implements Exception
{
    
}