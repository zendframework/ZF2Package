Zf-Content-Negotiation
======================

Manage the content negotiation mechanism to implement an API system with Zend Framework 2.


Installation
------------

You can install using:

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```

