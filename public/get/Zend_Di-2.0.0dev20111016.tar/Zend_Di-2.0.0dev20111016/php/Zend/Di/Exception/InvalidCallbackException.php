<?php
namespace Zend\Di\Exception;

class InvalidCallbackException extends InvalidArgumentException 
{
}
