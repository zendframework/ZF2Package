<?php


namespace Zend\Http\PhpEnvironment;

use Zend\Http\Response as HttpResponse,
    Zend\Stdlib\Parameters;

class Response extends HttpResponse
{
    public function __construct()
    {
    }
    
    public function headersSent()
    {
        
    }
    
    public function contentSent()
    {
        
    }
    
    public function sendHeaders()
    {
    }
    
    public function sendContent()
    {
    }

    public function send()
    {
    }
    
}
    