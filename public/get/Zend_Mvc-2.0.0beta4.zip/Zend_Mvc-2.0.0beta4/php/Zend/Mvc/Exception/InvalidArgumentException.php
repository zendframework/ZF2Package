<?php

namespace Zend\Mvc\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements ExceptionInterface
{}
