<?php

namespace Zend\Markup\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{}