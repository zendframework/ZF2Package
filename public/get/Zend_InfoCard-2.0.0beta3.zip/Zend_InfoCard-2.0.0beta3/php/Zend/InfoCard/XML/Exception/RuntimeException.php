<?php

namespace Zend\InfoCard\XML\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\InfoCard\XML\Exception
{}