<?php

namespace Zend\Stdlib;

class Response extends Message implements ResponseDescription
{
    // generic response implementation
}
