<?php

namespace Zend\Http\Header\Exception;

use Zend\Http\Header\Exception;

class RuntimeException 
    extends \RuntimeException 
    implements Exception
{
}
