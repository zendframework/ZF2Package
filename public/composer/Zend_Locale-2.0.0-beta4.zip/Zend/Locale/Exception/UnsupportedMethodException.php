<?php
namespace Zend\Locale\Exception;

class UnsupportedMethodException
    extends \RuntimeException
    implements ExceptionInterface
{}
