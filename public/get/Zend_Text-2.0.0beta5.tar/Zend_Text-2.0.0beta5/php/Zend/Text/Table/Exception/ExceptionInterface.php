<?php

namespace Zend\Text\Table\Exception;

use Zend\Text\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{}
