<?php

namespace Zend\Module;

interface Exception
{}
