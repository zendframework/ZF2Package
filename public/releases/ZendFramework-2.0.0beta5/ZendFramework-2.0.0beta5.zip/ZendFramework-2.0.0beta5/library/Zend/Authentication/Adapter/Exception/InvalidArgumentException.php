<?php

namespace Zend\Authentication\Adapter\Exception;

use Zend\Authentication\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{
} 
