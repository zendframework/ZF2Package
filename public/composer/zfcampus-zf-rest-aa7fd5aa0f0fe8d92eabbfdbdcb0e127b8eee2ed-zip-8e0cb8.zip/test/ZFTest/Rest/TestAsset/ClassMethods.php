<?php
/**
 * @license   http://opensource.org/licenses/BSD-3-Clause BSD-3-Clause
 * @copyright Copyright (c) 2013 Zend Technologies USA Inc. (http://www.zend.com)
 */

namespace ZFTest\Rest\TestAsset;

/**
 * @subpackage UnitTest
 */
class ClassMethods
{
    public function getFoo()
    {
        return 'bar';
    }
}
