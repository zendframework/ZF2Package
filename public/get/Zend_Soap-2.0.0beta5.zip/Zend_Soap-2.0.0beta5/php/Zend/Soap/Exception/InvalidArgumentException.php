<?php

namespace Zend\Soap\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements ExceptionInterface
{}