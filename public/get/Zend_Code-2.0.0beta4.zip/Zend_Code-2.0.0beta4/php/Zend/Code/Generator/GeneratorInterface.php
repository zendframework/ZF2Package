<?php

namespace Zend\Code\Generator;

interface GeneratorInterface
{
    public function generate();
}
