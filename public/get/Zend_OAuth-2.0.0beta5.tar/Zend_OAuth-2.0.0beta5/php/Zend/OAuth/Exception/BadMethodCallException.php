<?php

namespace Zend\OAuth\Exception;

class BadMethodCallException
    extends \BadMethodCallException
    implements ExceptionInterface
{}