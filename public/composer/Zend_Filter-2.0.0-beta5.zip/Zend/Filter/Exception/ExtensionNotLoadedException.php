<?php

namespace Zend\Filter\Exception;

class ExtensionNotLoadedException extends RuntimeException
{
}
