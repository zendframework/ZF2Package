<?php

namespace Zend\Mvc\Exception;

use Zend\Mvc\Exception,
    RuntimeException;

class MissingLocatorException extends RuntimeException implements Exception
{}
