<?php

namespace Zend\Code\Generator;

class FileGeneratorRegistry
{
    /**
     * @todo Complete this when Zend\Tool get's refractored as it is the only 
     *       piece that cares if its "double reflecting" file generators
     */
}