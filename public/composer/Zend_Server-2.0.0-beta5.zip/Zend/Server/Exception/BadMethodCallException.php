<?php

namespace Zend\Server\Exception;

class BadMethodCallException
    extends \BadMethodCallException
    implements ExceptionInterface
{}