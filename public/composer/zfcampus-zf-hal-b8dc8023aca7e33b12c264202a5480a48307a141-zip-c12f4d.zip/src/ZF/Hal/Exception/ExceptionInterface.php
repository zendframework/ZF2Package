<?php
/**
 * @license   http://opensource.org/licenses/BSD-2-Clause BSD-2-Clause
 */

namespace ZF\Hal\Exception;

/**
 * Marker interface; catch this to catch any module-specific exception.
 */
interface ExceptionInterface
{
}
