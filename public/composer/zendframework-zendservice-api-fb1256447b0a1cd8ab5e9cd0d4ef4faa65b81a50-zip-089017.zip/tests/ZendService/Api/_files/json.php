<?php
return array(
    'method' => 'GET',
    'response' => array(
        'format'      => 'json',
        'valid_codes' => array('200')
    )
);

