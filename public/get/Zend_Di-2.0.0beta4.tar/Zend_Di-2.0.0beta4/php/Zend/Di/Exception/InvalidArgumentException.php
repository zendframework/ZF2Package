<?php
namespace Zend\Di\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements ExceptionInterface
{
}
