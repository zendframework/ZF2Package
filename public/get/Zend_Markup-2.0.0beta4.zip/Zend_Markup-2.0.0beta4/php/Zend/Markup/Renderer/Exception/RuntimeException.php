<?php

namespace Zend\Markup\Renderer\Exception;

use Zend\Markup\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}