<?php

namespace Zend\OAuth\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{}