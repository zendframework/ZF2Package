<?php

namespace Zend\Code\Reflection\Exception;

class BadMethodCallException
    extends \BadMethodCallException
    implements \Zend\Code\Reflection\Exception
{}
