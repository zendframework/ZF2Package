<?php

namespace Zend\Config\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Config\Exception
{
}