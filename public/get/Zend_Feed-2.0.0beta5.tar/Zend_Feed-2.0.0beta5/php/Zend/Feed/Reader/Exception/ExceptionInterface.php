<?php

namespace Zend\Feed\Reader\Exception;

use Zend\Feed\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{}