<?php

namespace Zend\View;

class InvalidHelperException extends Exception
{
}
