<?php

namespace Zend\Http\Header\Exception;

use Zend\Http\Exception\ExceptionInterface as HttpException;

interface ExceptionInterface
    extends HttpException
{
}
