<?php

namespace Zend\Code\Scanner;

class VariableScanner
{
    // @todo
}
