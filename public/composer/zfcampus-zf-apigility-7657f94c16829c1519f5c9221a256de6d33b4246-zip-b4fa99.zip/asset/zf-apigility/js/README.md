Files in this directory
=======================

- bootstrap.min.js: Minified version of the Bootstrap 3 javascript.
- jquery.min.js: Minified version of jquery 2.0.3
- angular-jquery-bootstrap.min.js: Minified version of angular 1.0.8, bootstrap
  3, and jquery 2.0.3
- apigility-utils.min.js: Minified versions of lodash, q, URI, URITemplate, and
  Hyperagent (the latter is useful for interacting with HAL responses)
