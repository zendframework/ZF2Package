<?php

namespace Zend\Text\Table\Exception;

use Zend\Text\Exception;

class OutOfBoundsException 
    extends Exception\OutOfBoundsException
    implements ExceptionInterface
{}