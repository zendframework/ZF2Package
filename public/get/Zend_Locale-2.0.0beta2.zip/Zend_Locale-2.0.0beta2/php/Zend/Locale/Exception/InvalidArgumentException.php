<?php
namespace Zend\Locale\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Locale\Exception
{}