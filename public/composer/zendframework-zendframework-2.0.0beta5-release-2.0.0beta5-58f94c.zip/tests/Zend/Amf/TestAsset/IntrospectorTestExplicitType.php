<?php

namespace ZendTest\Amf\TestAsset;

class IntrospectorTestExplicitType
{
    public $_explicitType = 'explicit';
}
