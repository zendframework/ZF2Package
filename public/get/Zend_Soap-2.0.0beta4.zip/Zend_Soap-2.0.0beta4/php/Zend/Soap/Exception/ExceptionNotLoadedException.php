<?php

namespace Zend\Soap\Exception;

class ExtensionNotLoadedException extends RuntimeException
{}