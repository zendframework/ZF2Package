# ZendService\Twitter component

Master: [![Build Status](https://secure.travis-ci.org/zendframework/ZendService_Twitter.png?branch=master)](http://travis-ci.org/zendframework/ZendService_Twitter)

You can install using:

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```

At that point, follow the instructions in the documentation folder for actual
usage of the component. (Documentation is forthcoming.)
