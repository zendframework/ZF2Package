<?php

namespace Zend\Text\Exception;

use Zend\Text\Exception;

class OutOfBoundsException 
    extends \OutOfBoundsException
    implements ExceptionInterface
{}