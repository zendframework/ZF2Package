<?php

namespace Zend\Server\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{}