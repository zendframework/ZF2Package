<?php

namespace Zend\Module\Listener;

interface Exception extends \Zend\Module\Exception
{}
