<?php

namespace Zend\InfoCard\XML\Security\Exception;

class ExtensionNotLoadedException
    extends RuntimeException
{}
