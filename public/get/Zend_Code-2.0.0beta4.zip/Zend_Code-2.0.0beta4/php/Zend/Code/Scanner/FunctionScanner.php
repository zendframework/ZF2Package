<?php

namespace Zend\Code\Scanner;

class FunctionScanner
{
    // @todo
    // Should this extend something similar to MethodScanner? Similar to ReflectionFunctionAbstract
}
