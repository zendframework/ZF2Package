# ZendService\Amazon component

[![Build Status](https://travis-ci.org/zendframework/ZendService_Amazon.png)](https://travis-ci.org/zendframework/ZendService_Amazon)

## Installation

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```

## Documentation

Read [the documentation](http://zf2.readthedocs.org/en/latest/modules/zendservice.amazon.html) for the ZendService\Amazon component.
