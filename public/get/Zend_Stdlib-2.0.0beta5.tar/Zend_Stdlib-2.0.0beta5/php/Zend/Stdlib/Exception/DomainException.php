<?php

namespace Zend\Stdlib\Exception;

class DomainException extends \DomainException implements ExceptionInterface
{
}
