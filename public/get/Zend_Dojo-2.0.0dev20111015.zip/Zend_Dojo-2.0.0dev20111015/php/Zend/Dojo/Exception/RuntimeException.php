<?php

namespace Zend\Dojo\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Dojo\Exception
{}