<?php

namespace Zend\Code\Exception;

use Zend\Code\Exception;

class RuntimeException extends \RuntimeException implements Exception
{
}
