<?php
/**
 * @license   http://opensource.org/licenses/BSD-3-Clause BSD-3-Clause
 * @copyright Copyright (c) 2013 Zend Technologies USA Inc. (http://www.zend.com)
 */

namespace ZF\Apigility\Example\V1\Rest\Status;

use Zend\Paginator\Paginator;

class StatusCollection extends Paginator
{
}
