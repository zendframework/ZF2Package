<?php
/**
 * @license   http://opensource.org/licenses/BSD-2-Clause BSD-2-Clause
 */

require __DIR__ . '/src/ZF/Hal/Module.php';
