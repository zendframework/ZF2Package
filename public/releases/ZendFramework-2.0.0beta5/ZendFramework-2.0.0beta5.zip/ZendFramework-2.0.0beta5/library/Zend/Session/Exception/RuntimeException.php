<?php

namespace Zend\Session\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{}
