<?php
namespace Zend\Translator\Adapter;

interface Exception extends \Zend\Translator\Exception
{}
