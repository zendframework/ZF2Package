<?php
/**
 * @namespace
 */
namespace Zend\Text\Table\Exception;

class UnexpectedValueException
	extends \UnexpectedValueException
	implements \Zend\Text\Exception
{
}
