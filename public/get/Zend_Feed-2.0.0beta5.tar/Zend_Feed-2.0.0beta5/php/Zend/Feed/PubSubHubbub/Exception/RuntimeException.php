<?php

namespace Zend\Feed\PubSubHubbub\Exception;

use Zend\Feed\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}