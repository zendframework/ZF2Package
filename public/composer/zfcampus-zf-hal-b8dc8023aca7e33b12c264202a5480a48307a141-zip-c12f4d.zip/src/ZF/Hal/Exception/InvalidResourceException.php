<?php
/**
 * @license   http://opensource.org/licenses/BSD-2-Clause BSD-2-Clause
 */

namespace ZF\Hal\Exception;

class InvalidResourceException extends InvalidArgumentException
{
}
