<?php
class InvalidInterfaceAutoloader
{
}
