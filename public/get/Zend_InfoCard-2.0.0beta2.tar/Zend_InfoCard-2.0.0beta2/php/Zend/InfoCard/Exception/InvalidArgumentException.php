<?php

namespace Zend\InfoCard\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\InfoCard\Exception
{}