<?php

namespace Zend\Server\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements ExceptionInterface
{}