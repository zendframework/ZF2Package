Api-Problem: ZF2 Module for API-Problem representations
=======================================================

This module provides data structures and rendering for the API-Problem format.

- [Problem API](http://tools.ietf.org/html/draft-nottingham-http-problem-02),
  used for reporting API problems
