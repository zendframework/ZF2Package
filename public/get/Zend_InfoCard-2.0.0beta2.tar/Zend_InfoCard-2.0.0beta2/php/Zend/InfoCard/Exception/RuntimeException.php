<?php

namespace Zend\InfoCard\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\InfoCard\Exception
{}