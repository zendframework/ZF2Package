<?php
namespace Zend\Module\Exception;

use Zend\Module\Exception;

class RuntimeException
    extends \RuntimeException
    implements Exception
{}
