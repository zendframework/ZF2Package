<?php
namespace Zend\Di;

interface Exception
{
}
