<?php

namespace Zend\Uri\Exception;

class InvalidArgumentException
	extends \InvalidArgumentException
	implements \Zend\Uri\Exception
{}
