<?php
/**
 * @namespace
 */
namespace Zend\Text\Table\Exception;

class InvalidArgumentException
	extends \InvalidArgumentException
	implements \Zend\Text\Exception
{
}
