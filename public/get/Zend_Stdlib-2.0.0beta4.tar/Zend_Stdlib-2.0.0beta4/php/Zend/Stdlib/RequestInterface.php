<?php

namespace Zend\Stdlib;

interface RequestInterface extends MessageInterface
{
}
