<?php

namespace Zend\Mvc\Exception;

interface ExceptionInterface
{}
