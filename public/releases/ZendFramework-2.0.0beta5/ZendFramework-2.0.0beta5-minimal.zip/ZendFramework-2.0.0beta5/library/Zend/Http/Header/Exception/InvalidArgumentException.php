<?php

namespace Zend\Http\Header\Exception;

use Zend\Http\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{
}
