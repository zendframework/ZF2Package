ZendService\Google\C2dm component
================================

Provides support for Google push notifications on deprecated C2dm.

Install dependencies using:

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```
