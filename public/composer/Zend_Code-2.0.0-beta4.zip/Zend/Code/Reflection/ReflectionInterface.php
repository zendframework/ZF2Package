<?php

namespace Zend\Code\Reflection;

use Reflector;

interface ReflectionInterface extends Reflector
{
    public function toString();
}
