<?php
namespace Zend\Tag\Cloud\Decorator\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Tag\Cloud\Decorator\Exception
{} 