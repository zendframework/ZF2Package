<?php

namespace Zend\Validator\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{}