<?php

namespace Zend\Feed\Reader\Exception;

use Zend\Feed\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}