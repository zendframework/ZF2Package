<?php

namespace Zend\Text\Table\Exception;

use Zend\Text\Exception;

class OverflowException
    extends Exception\OverflowException
    implements ExceptionInterface
{}