<?php

namespace Zend\Navigation\Exception;

use Zend\Navigation\Exception;

class DomainException extends \DomainException implements Exception
{
    
}
