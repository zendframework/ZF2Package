<?php
class Zend_Amf_Adobe_TestAsset_ParameterHints
{
    public function argSimReturn(array $arg1, array $arg2, $arg3)
    { 
        return $arg1; 
    }
}
