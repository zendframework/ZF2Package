<?php

namespace Zend\InfoCard\XML\Exception;

use Zend\InfoCard\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}