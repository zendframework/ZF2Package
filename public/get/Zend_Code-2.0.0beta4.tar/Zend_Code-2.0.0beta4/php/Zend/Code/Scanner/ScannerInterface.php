<?php

namespace Zend\Code\Scanner;

interface ScannerInterface
{
    /* public static function export($tokens); */
    /* public function toString(); */
}
