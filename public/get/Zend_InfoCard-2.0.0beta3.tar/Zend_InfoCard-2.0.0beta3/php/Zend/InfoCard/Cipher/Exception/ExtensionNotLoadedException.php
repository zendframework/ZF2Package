<?php

namespace Zend\InfoCard\Cipher\Exception;

class ExtensionNotLoadedException
    extends \RuntimeException
    implements \Zend\InfoCard\Cipher\Exception
{}
