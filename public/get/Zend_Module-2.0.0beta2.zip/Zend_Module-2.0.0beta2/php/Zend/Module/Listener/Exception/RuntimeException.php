<?php

namespace Zend\Module\Listener\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Module\Listener\Exception
{}
