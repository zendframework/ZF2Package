<?php

namespace Zend\Feed\PubSubHubbub\Exception;

use Zend\Feed\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{}