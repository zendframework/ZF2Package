<?php

namespace Zend\Soap\Exception;

class UnexpectedValueException
    extends \UnexpectedValueException
    implements ExceptionInterface
{}