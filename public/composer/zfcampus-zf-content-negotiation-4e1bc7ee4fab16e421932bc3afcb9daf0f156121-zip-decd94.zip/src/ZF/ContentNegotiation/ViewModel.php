<?php

namespace ZF\ContentNegotiation;

use Zend\View\Model\ViewModel as BaseViewModel;

class ViewModel extends BaseViewModel
{
}
