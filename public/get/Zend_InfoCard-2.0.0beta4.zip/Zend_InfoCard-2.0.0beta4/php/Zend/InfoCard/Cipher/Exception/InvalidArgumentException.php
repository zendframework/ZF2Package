<?php

namespace Zend\InfoCard\Cipher\Exception;

use Zend\InfoCard\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{}