<?php

namespace Zend\Code\Scanner;

class ValueScanner
{
    // @todo
}
