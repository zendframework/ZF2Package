<?php

namespace Zend\ServiceManager\Exception;

class InvalidServiceNameException extends RuntimeException
{}