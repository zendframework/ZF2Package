<?php

namespace Zend\Acl\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Acl\Exception\ExceptionInterface
{
    
}
