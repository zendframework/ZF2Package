<?php

namespace ZendTest\Amf\TestAsset;

class SerializableData
{
    public function __toString()
    {
        return __CLASS__;
    }
}
