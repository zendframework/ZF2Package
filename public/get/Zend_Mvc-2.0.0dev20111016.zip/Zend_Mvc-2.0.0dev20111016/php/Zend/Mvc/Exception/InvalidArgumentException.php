<?php

namespace Zend\Mvc\Exception;

use Zend\Mvc\Exception;

class InvalidArgumentException 
    extends \InvalidArgumentException
    implements Exception
{}
