<?php

namespace Zend\Filter\Exception;

class BadMethodCallException 
    extends \BadMethodCallException
    implements \Zend\Filter\Exception
{
}
