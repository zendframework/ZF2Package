<?php

namespace Zend\Http\Exception;

class OutOfRangeException
    extends \OutOfRangeException
    implements ExceptionInterface
{}