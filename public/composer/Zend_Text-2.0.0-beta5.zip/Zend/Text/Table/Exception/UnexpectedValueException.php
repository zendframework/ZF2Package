<?php

namespace Zend\Text\Table\Exception;

use Zend\Text\Exception;

class UnexpectedValueException
    extends Exception\UnexpectedValueException
    implements ExceptionInterface
{}