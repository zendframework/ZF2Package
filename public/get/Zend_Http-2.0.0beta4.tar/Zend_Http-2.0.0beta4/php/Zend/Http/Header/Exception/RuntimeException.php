<?php

namespace Zend\Http\Header\Exception;

use Zend\Http\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{
}
