<?php

namespace Zend\Http\Exception;

interface ExceptionInterface
{
}
