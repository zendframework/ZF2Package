<?php

namespace Zend\InfoCard\Cipher\Exception;

use Zend\InfoCard\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}