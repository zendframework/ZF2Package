Converting To Exceptions
------------------------
Since this is a community effort, this list will serve as a place where the community
can keep track of which components are complete, currently being worked on, or available
to be worked on.

Progress tracked here: http://framework.zend.com/wiki/display/ZFDEV2/Milestone+Exceptions



Known Issues
------------
* Zend/Mail - Must convert tests to use setExpectedException, evironment needed to run tests
