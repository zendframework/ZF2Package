<?php

namespace Zend\Server\Reflection\Exception;

use Zend\Server\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{}