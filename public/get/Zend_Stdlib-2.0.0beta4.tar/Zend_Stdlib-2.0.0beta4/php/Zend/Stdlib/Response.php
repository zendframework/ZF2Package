<?php

namespace Zend\Stdlib;

class Response extends Message implements ResponseInterface
{
    // generic response implementation
}
