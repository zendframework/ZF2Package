<?php

namespace Zend\Soap\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{}