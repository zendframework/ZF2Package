<?php
namespace Zend\Rest\Client\Exception;

class UnexpectedValueException
    extends \UnexpectedValueException
    implements \Zend\Rest\Client\Exception
{}