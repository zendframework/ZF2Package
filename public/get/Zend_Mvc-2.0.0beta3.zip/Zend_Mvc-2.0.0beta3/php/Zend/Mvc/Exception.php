<?php

namespace Zend\Mvc;

interface Exception
{}
