<?php

namespace Zend\Di\Definition;

interface PartialMarker
{

}
