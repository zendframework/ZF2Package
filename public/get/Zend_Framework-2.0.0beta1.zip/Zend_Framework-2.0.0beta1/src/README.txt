Zend_Framework Meta Package
===========================

To install package groups, use this format for the installer

  pyrus install -f zf2/Zend_Framework#MVC

Groups
------

  
