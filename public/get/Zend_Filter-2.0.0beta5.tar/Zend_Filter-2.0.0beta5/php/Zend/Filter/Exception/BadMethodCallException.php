<?php

namespace Zend\Filter\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
