<?php

namespace Zend\Code\Annotation;

interface AnnotationInterface
{
    /**
     * Initialize
     *
     * @param $content
     */
    public function initialize($content);
}
