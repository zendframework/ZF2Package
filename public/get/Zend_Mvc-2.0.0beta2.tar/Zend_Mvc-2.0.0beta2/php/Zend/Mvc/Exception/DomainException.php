<?php

namespace Zend\Mvc\Exception;

use Zend\Mvc\Exception;

class DomainException extends \DomainException implements Exception
{}
