<?php

namespace Zend\Stdlib;

interface RequestDescription extends MessageDescription
{
}
