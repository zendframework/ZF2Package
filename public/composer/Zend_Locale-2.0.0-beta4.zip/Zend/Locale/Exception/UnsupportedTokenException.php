<?php
namespace Zend\Locale\Exception;

class UnsupportedTokenException
    extends \RuntimeException
    implements ExceptionInterface
{}
