<?php

namespace ZendTest\Amf\TestAsset;

/**
 * @see ReferenceTest
 */
class TestObject 
{
    public $recursive;
}
