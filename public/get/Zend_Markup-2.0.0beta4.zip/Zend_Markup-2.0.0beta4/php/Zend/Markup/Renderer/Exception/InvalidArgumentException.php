<?php

namespace Zend\Markup\Renderer\Exception;

use Zend\Markup\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{}
