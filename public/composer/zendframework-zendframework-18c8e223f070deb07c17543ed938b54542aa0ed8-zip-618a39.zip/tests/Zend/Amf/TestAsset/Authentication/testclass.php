<?php

namespace ZendTest\Amf\TestAsset\Authentication;

class testclass 
{
    function hello() 
    {
        return "hello!";
    }
}
