Apigility Welcome Screen
========================

Welcome page for the web interface of the [Apigility](http://www.apigility.org) project.


Installation
------------

You can install using:

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```

