<?php
namespace Zend\Tag\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Tag\Exception
{}