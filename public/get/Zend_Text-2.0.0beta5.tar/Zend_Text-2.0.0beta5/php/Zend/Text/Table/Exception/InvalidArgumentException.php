<?php
namespace Zend\Text\Table\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements ExceptionInterface
{
}
