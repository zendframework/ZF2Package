<?php

class AutoloaderTest_AutoloaderClosure
{
}
