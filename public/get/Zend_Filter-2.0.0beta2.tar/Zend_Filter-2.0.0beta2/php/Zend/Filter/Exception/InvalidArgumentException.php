<?php

namespace Zend\Filter\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Filter\Exception
{
}