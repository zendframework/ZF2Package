<?php
namespace Zend\Di\Exception;

interface ExceptionInterface
{
}
