ZendGData component
===================

**UNMAINTAINED COMPONENT**

This component is unmaintained.  If you require API access to the Google api,
please consider using https://code.google.com/p/google-api-php-client/

You can install using:

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```

At that point, follow the instructions in the documentation folder for actual
usage of the component. (Documentation is forthcoming.)
