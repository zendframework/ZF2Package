<?php
namespace Zend\Di\Exception;

use DomainException;

class ClassNotFoundException extends DomainException implements ExceptionInterface
{
}
