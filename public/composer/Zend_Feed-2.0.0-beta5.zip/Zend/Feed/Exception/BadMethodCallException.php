<?php

namespace Zend\Feed\Exception;

class BadMethodCallException
    extends \BadMethodCallException
    implements ExceptionInterface
{}