Apigility Example
=================

Example API for the [Apigility](http://www.apigility.org) project.


Installation
------------

You can install using:

```
curl -s https://getcomposer.org/installer | php
php composer.phar install
```
