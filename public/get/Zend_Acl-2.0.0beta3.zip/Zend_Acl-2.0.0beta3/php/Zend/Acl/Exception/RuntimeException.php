<?php

namespace Zend\Acl\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Acl\Exception
{
    
}