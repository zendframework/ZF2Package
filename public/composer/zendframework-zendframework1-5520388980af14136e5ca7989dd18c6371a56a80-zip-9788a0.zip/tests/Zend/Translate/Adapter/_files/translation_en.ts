<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS>
<context>
    <name>Test</name>
    <message>
        <source>Message 1</source>
        <translation>Message 1 (en)</translation>
    </message>
    <message>
        <source>Message 2</source>
        <translation>Message 2 (en)</translation>
    </message>
    <message>
        <source>Message 3</source>
        <translation>Message 3 (en)</translation>
    </message>
    <message>
        <source>Message 4</source>
        <translation>Message 4 (en)</translation>
    </message>
    <message>
        <source>Küchen Möbel</source>
        <translation>Cooking furniture (en)</translation>
    </message>
    <message>
        <source>Cooking furniture</source>
        <translation>Küchen Möbel (en)</translation>
    </message>
</context>
</TS>
