<?php

namespace Zend\Stdlib\Exception;

use Zend\Stdlib\Exception;

class DomainException extends \DomainException implements Exception
{
}
