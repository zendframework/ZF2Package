<?php

namespace Zend\Dojo\View\Exception;

class BadMethodCallException
    extends \BadMethodCallException
    implements \Zend\Dojo\View\Exception
{}