<?php
namespace Zend\Tag\Exception;

class OutOfBoundsException
	extends \OutOfBoundsException
	implements \Zend\Tag\Exception
{}