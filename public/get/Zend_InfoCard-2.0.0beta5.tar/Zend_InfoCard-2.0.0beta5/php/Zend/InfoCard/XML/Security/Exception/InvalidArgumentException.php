<?php

namespace Zend\InfoCard\XML\Security\Exception;

use Zend\InfoCard\XML\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{}