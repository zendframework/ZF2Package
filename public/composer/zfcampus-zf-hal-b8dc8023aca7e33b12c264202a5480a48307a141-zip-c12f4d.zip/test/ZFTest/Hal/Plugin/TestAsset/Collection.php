<?php

namespace ZFTest\Hal\Plugin\TestAsset;

use ArrayObject;

class Collection extends ArrayObject
{
}
