<?php

namespace Zend\Navigation\Exception;

use Zend\Navigation\Exception;

class BadMethodCallException extends \InvalidArgumentException implements Exception
{
    
}