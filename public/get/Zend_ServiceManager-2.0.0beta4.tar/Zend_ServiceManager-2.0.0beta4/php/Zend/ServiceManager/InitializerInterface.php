<?php

namespace Zend\ServiceManager;

interface InitializerInterface
{
    public function initialize($instance);
}
