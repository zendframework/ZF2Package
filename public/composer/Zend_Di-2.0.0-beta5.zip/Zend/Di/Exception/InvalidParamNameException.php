<?php
namespace Zend\Di\Exception;

class InvalidParamNameException extends InvalidArgumentException
{
}
