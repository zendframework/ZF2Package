<?php

namespace Zend\Code;

use Reflector;

interface Reflection extends Reflector
{
    public function toString();
}
