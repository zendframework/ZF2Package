<?php

namespace Zend\ServiceManager\Exception;

interface ExceptionInterface
{
}
