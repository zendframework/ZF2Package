<?php

namespace Zend\Soap\Exception;

class BadMethodCallException
    extends \BadMethodCallException
    implements ExceptionInterface
{}