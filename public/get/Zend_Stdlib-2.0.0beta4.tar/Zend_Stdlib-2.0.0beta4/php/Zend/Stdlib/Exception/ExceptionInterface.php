<?php

namespace Zend\Stdlib\Exception;

interface ExceptionInterface
{
}
