<?php
/**
 * @license   http://opensource.org/licenses/BSD-2-Clause BSD-2-Clause
 */

namespace ZFTest\Hal\TestAsset;

/**
 * @subpackage UnitTest
 */
class ClassMethods
{
    public function getFoo()
    {
        return 'bar';
    }
}
