<?php

namespace Zend\View;

class InvalidArgumentException extends \InvalidArgumentException
{
}
