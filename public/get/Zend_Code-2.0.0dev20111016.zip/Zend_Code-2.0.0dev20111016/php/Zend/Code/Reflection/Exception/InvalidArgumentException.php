<?php

namespace Zend\Code\Reflection\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Code\Reflection\Exception
{}
