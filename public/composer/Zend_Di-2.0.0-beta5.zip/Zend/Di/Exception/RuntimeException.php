<?php
namespace Zend\Di\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
