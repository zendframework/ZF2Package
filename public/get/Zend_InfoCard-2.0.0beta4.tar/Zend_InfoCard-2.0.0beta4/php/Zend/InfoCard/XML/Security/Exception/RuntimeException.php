<?php

namespace Zend\InfoCard\XML\Security\Exception;

use Zend\InfoCard\XML\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}