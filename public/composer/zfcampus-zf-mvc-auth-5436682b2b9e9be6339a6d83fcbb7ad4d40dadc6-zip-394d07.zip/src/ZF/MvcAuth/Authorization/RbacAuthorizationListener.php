<?php

namespace ZF\MvcAuth\Authorization;

use Zend\Permissions\Rbac\Rbac;
use ZF\MvcAuth\MvcAuthEvent;

class RbacAuthorizationListener
{
    public function __invoke(MvcAuthEvent $mvcAuthEvent)
    {
    }
}
