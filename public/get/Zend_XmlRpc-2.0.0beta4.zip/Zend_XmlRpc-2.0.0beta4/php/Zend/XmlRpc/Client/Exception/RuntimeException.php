<?php

namespace Zend\XmlRpc\Client\Exception;

use Zend\XmlRpc\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}