<?php

namespace Zend\Server\Reflection\Exception;

use Zend\Server\Exception;

class RuntimeException
    extends Exception\RuntimeException
    implements ExceptionInterface
{}