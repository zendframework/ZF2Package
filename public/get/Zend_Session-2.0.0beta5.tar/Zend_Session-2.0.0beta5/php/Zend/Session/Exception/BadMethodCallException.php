<?php

namespace Zend\Session\Exception;

class BadMethodCallException
    extends \BadMethodCallException
    implements ExceptionInterface
{}
