<?php

namespace Zend\OpenId\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{}