<?php

namespace Zend\Text\Exception;

use Zend\Text\Exception;

class OverflowException
    extends \OverflowException
    implements ExceptionInterface
{}