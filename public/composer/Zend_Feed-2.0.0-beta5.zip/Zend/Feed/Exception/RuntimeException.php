<?php

namespace Zend\Feed\Exception;

class RuntimeException
    extends \RuntimeException
    implements ExceptionInterface
{}