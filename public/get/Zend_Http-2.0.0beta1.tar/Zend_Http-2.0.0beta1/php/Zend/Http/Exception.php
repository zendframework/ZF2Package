<?php

namespace Zend\Http;

interface Exception
{
}
