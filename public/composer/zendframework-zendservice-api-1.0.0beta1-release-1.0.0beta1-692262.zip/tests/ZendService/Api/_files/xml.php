<?php
return array(
    'method' => 'GET',
    'response' => array(
        'format'      => 'xml',
        'valid_codes' => array('200')
    )
);
