<?php

namespace Zend\InfoCard\Cipher\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\InfoCard\Cipher\Exception
{}