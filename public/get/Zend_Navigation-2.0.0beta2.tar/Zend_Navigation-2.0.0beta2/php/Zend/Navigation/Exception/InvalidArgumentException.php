<?php

namespace Zend\Navigation\Exception;

use Zend\Navigation\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements Exception
{
    
}