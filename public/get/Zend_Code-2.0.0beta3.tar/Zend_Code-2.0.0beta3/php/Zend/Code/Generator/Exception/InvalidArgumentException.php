<?php

namespace Zend\Code\Generator\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Code\Generator\Exception
{}
