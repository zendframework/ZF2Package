<?php

namespace Zend\Feed\Reader\Exception;

use Zend\Feed\Exception;

class InvalidArgumentException
    extends Exception\InvalidArgumentException
    implements ExceptionInterface
{}